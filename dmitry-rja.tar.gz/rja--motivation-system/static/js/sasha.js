    function klikaj(i)
{
    top.location.href='mark_user.html'
}

        function profil(i)
{
    top.location.href='Dmitry_Shop.html'
}

        function statistica(i)
{
    top.location.href='Dmitry_Table.html'
}